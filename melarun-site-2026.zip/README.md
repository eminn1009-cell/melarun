MelaRun — Web sitesi

## Yerelde çalıştırma
Klasörde terminal açıp `python -m http.server 8000` çalıştırın; ardından http://localhost:8000 adresini açın.

## GitHub’a yükleme
Bu klasörün içeriğini GitHub deposunun köküne yükleyin ve `main` branch’ine commit edin.

## Vercel
Bu klasörü GitHub’a push ettikten sonra Vercel’de **Add New → Project** ile doğru repository ve `main` branch’ini seçin. Framework Preset: **Other**, Build Command boş, Output Directory `.`.

Supabase tarayıcı bağlantı ayarları `supabase-config.js` dosyasındadır.
