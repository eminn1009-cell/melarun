MelaRun — yeni proje klasörü

Bu klasör, sadeleştirilmiş tasarım dosyalarını içerir.
Yerelde çalıştırmak için klasörde terminal açıp: python -m http.server 8000
Ardından http://localhost:8000 adresini açın.

Supabase bağlantı ayarları supabase-config.js içindedir.
